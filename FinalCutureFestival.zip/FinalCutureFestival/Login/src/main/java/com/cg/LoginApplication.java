package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.cg.beans.Admin;
import com.cg.dao.LoginDao;

@SpringBootApplication
public class LoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginApplication.class, args);
	}
	
//	
//   @Bean
//   public Admin addAdmin(LoginDao dao) {
//	   Admin admin=new Admin("Admin","123");
//	  return dao.save(admin);
//   }
}
