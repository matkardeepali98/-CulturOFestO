package com.cg.event;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.cg.event.entity.Event;
import com.cg.event.entity.Food;
import com.cg.event.exception.EmptyListException;
import com.cg.event.service.EventService;
import com.cg.event.service.EventServiceImpl;
/**
 * 
 * @author Shubham Sharma
 */
@SpringBootTest
class EventServiceApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void addEvent() throws AddressException, MessagingException, IOException {
		List<Food> food = new ArrayList<>();
		Food food1 = new Food("Bature", 70.0, "Adult", "Lunch");
		Food food2 = new Food("Rice", 60.0, "Adult", "Lunch");
		Food food3 = new Food("Daal", 50.0, "Kid", "Lunch");

		food.add(food1);
		food.add(food2);
		food.add(food3);

		Event event = new Event("Holi", "Pune", 456.0, LocalDate.of(2021, 02, 25), LocalDate.of(2021, 02, 27),
				LocalDate.of(2021, 02, 20), food);
		EventService eventService = mock(EventServiceImpl.class);
		when(eventService.addevent(event)).thenReturn(event);

		Event event2 = eventService.addevent(event);
		assertEquals(event, event2);
	}

	@Test
	void updateEvent() throws AddressException, MessagingException, IOException {
		List<Food> food = new ArrayList<>();
		Food food1 = new Food("Bature", 70.0, "Adult", "Lunch");
		Food food2 = new Food("Rice", 60.0, "Adult", "Lunch");
		Food food3 = new Food("Daal", 50.0, "Kid", "Lunch");

		food.add(food1);
		food.add(food2);
		food.add(food3);

		Event event = new Event("Holi", "Pune", 456.0, LocalDate.of(2021, 02, 25), LocalDate.of(2021, 02, 27),
				LocalDate.of(2021, 02, 20), food);
		EventService eventService = mock(EventServiceImpl.class);
		eventService.addevent(event);
		Event event2 = new Event("Ganesh", "Hadapsar", 456.0, LocalDate.of(2021, 02, 25), LocalDate.of(2021, 02, 27),
				LocalDate.of(2021, 02, 20), food);
		when(eventService.update(event2)).thenReturn(event2);

		Event event3 = eventService.update(event2);
		assertEquals(event2, event3);
	}

	@Test
	void findAllEvents() throws EmptyListException {

		List<Food> foodlist1 = new ArrayList<>();
		Food food1 = new Food("Bature", 70.0, "Adult", "Lunch");
		Food food2 = new Food("Rice", 60.0, "Adult", "Lunch");

		foodlist1.add(food1);
		foodlist1.add(food2);

		List<Food> foodlist2 = new ArrayList<>();
		Food food3 = new Food("Daal", 50.0, "Kid", "Lunch");

		foodlist2.add(food3);

		List<Event> event = new ArrayList<>();
		Event event1 = new Event("Holi", "Pune", 456.0, LocalDate.of(2021, 02, 25), LocalDate.of(2021, 02, 27),
				LocalDate.of(2021, 02, 20), foodlist1);
		Event event2 = new Event("Ganesh", "Pune", 456.0, LocalDate.of(2021, 02, 25), LocalDate.of(2021, 02, 27),
				LocalDate.of(2021, 02, 20), foodlist2);
		event.add(event1);
		event.add(event2);
		EventService eventService = mock(EventServiceImpl.class);
		when(eventService.fetchall()).thenReturn(event);
		List<Event> eventlist = eventService.fetchall();
		assertNotNull(eventlist);
		assertFalse(eventlist.isEmpty());
	}

	@Test
	void deleteEvent() {

		List<Food> food = new ArrayList<>();
		Food food1 = new Food("Bature", 70.0, "Adult", "Lunch");
		Food food2 = new Food("Rice", 60.0, "Adult", "Lunch");
		Food food3 = new Food("Daal", 50.0, "Kid", "Lunch");

		food.add(food1);
		food.add(food2);
		food.add(food3);

		List<Event> event = new ArrayList<>();
		Event event1 = new Event("Holi", "Pune", 456.0, LocalDate.of(2021, 02, 25), LocalDate.of(2021, 02, 27),
				LocalDate.of(2021, 02, 20), food);
		Event event2 = new Event("Ganesh", "Pune", 456.0, LocalDate.of(2021, 02, 25), LocalDate.of(2021, 02, 27),
				LocalDate.of(2021, 02, 20), food);
		event.add(event1);
		event.add(event2);

		EventService eventService = mock(EventServiceImpl.class);
		when(eventService.delete(4L)).thenReturn(event);
		List<Event> eventlist = eventService.delete(4L);
		assertNotNull(eventlist);
		assertFalse(eventlist.isEmpty());
	}

	@Test
	void getList() {
		List<Food> food = new ArrayList<>();
		Food food1 = new Food("Bature", 70.0, "Adult", "Lunch");
		Food food2 = new Food("Rice", 60.0, "Adult", "Lunch");
		Food food3 = new Food("Daal", 50.0, "Kid", "Lunch");

		food.add(food1);
		food.add(food2);
		food.add(food3);

		Event event = new Event("Holi", "Pune", 456.0, LocalDate.of(2021, 02, 25), LocalDate.of(2021, 02, 27),
				LocalDate.of(2021, 02, 20), food);

		EventService eventService = mock(EventServiceImpl.class);
		when(eventService.listfood(4L)).thenReturn(event.getFoods());
		List<Food> foodlist = eventService.listfood(4L);
		assertNotNull(foodlist);
		assertEquals(food, foodlist);

	}

}
