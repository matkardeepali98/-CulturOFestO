package com.cg.event.service;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.imageio.ImageIO;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.event.entity.Event;
import com.cg.event.entity.Food;
import com.cg.event.exception.EmptyListException;
import com.cg.event.exception.NotPossibleException;
import com.cg.event.repository.EventRepository;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import net.glxn.qrgen.javase.QRCode;


@Service
public class EventServiceImpl implements EventService {

	@Autowired
	private EventRepository repo;

	private static final Logger logger = LoggerFactory.getLogger(EventServiceImpl.class);

	String appointmentNotPresent = "No appointment present with this appointment Id";
	String diagnosticCenterNotPresent = "No diagnostic center present with this diagnostic center Id";
	String userNotPresent = "No user present with this user Id";

	public boolean validateDate(LocalDate lastdate, LocalDate eventlastdate) {

		if (lastdate.isBefore(LocalDate.now())) { // if date is less than current date
			logger.warn("Invalid date");
			throw new NotPossibleException("Please select a valid date");
		} else if (!lastdate.isBefore(eventlastdate)) {
			logger.warn("Invalid date");
			throw new NotPossibleException("Please select a date before 3 days of la");
		} else
			return true;
	}

	private void sendmail(String Name, String Venue, LocalDate from, LocalDate To)
			throws AddressException, MessagingException, IOException {

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.googlemail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("healthcaresystem12@gmail.com", "hcs@1234");
			}
		});
		Message msg = new MimeMessage(session);
		msg.setFrom(new InternetAddress("healthcaresystem12@gmail.com", false));

		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("yash.pawar642@gmail.com"));
		msg.setSubject("Approval  email");
		msg.setContent("Your Event is Listed for The Fest with Name:" + Name + ", at center:" + Venue + ", on date :"
				+ from + " to date :" + To, "text/html");
		msg.setSentDate(new Date());

		MimeBodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setContent("Your Event is Listed for The Fest with Name:" + Name + ", at center:" + Venue
				+ ", on date :" + from + " to date :" + To, "text/html");
		// Transport.send(msg);

		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(messageBodyPart);
		MimeBodyPart attachPart = new MimeBodyPart();

		attachPart.attachFile("C:/Users/Isha Pawar/Desktop/New Project/approved.jpg");
		multipart.addBodyPart(attachPart);
		msg.setContent(multipart);
		Transport.send(msg);
	}

	@Override
	public List<Event> fetchall() throws EmptyListException {
		List<Event> eventList = repo.findAll();
		if(eventList.isEmpty())
			throw new EmptyListException("List is Empty");
		return eventList; 
	}

	@Override
	public Event update(Event event) throws AddressException, MessagingException, IOException {
//		if (event.getDateFrom().isAfter(LocalDate.now()) && event.getDateTo().isAfter(event.getDateFrom())
//				&& event.getDateFrom().isAfter(event.getLastDate()) && event.getLastDate().isAfter(LocalDate.now())) {
//			sendmail(event.getName(), event.getVenue(), event.getDateFrom(), event.getDateTo());
			return this.repo.save(event);
//		} else
//			throw new NotPossibleException("Enter Valid Dates");
	}

	@Override
	public List<Event> delete(Long EventId) {
		repo.deleteById(EventId);
		return repo.findAll();
	}

	@Override
	public Event addevent(Event event) throws AddressException, MessagingException, IOException {

		
//		if (event.getDateFrom().isAfter(LocalDate.now()) && event.getDateTo().isAfter(event.getDateFrom())// date
//																											// validations
//				&& event.getDateFrom().isAfter(event.getLastDate()) && event.getLastDate().isAfter(LocalDate.now())) {

		//	sendmail(event.getName(), event.getVenue(), event.getDateFrom(), event.getDateTo());
			
			return this.repo.save(event);

//		} else
//			throw new NotPossibleException("Enter Valid Dates");

	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public BufferedImage generateQRCodeImage(String barcodeText) throws Exception {
	    ByteArrayOutputStream stream = QRCode
	      .from(barcodeText)
	      .withSize(500, 500)
	      .stream();
	    ByteArrayInputStream bis = new ByteArrayInputStream(stream.toByteArray());

	    return ImageIO.read(bis);
	}
	@Override
	public void generateQRCodeImage(String text, String filePath)
            throws WriterException, IOException {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        BitMatrix bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, 500, 500);

        Path path = FileSystems.getDefault().getPath(filePath);
        MatrixToImageWriter.writeToPath(bitMatrix, "PNG", path);
       
    }
	
	@Override
	public byte[] getQRCodeImage(String text) throws WriterException, IOException {
	    QRCodeWriter qrCodeWriter = new QRCodeWriter();
	    BitMatrix bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, 500, 500);
	    
	    ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream();
	    MatrixToImageWriter.writeToStream(bitMatrix, "PNG", pngOutputStream);
	    byte[] pngData = pngOutputStream.toByteArray(); 
	    return pngData;
	}

	@Override
	public List<Food> listfood(Long id){
	//	Optional<Event> event = this.repo.findById(id);
		List<Event> abc = repo.findAll();
		for (Event event2 : abc) {
			if(event2.getEventId() == id)
				return event2.getFoods();
			
		}
		return null;
	}
	
	@Override
	public Event findbyid(Long id) {
		for (Event e : repo.findAll()) {
			if (e.getEventId() == id)
				return e;
		}
		return null;
	}

	@Override
	public List<Event> findbyname(String name) {
		List<Event> event = new ArrayList<Event>();
		for (Event e : repo.findAll()) {
			if (e.getName().equalsIgnoreCase(name))
				event.add(e);
		}
		return event;
	}

	@Override
	public List<Event> findbyvenue(String venue) {
		List<Event> event = new ArrayList<Event>();
		for (Event e : repo.findAll()) {
			if (e.getVenue().equalsIgnoreCase(venue))
				event.add(e);
		}
		return event;
	}

	@Override
	public List<Event> findbyeventfood(String name) {
		List<Event> event = new ArrayList<Event>();
		for (Event e : repo.findAll()) {
			for (Food f : e.getFoods()) {
				if (f.getName().equalsIgnoreCase(name)) {
					event.add(e);
					break;
				} // if
			} // inner for
		} // for
		return event;
	}
	
	
}
