package com.cg.event.service;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.cg.event.entity.Event;
import com.cg.event.entity.Food;
import com.cg.event.exception.EmptyListException;
import com.google.zxing.WriterException;

public interface EventService {

	List<Event> fetchall() throws EmptyListException;

	Event update(Event event) throws AddressException, MessagingException, IOException;

	List<Event> delete(Long EventId);

	Event addevent(Event event) throws AddressException, MessagingException, IOException;

	BufferedImage generateQRCodeImage(String barcodeText) throws Exception;

	void generateQRCodeImage(String text, String filePath) throws WriterException, IOException;

	byte[] getQRCodeImage(String text) throws WriterException, IOException;

	List<Food> listfood(Long id);

	Event findbyid(Long id);

	List<Event> findbyname(String name);

	List<Event> findbyvenue(String venue);

	List<Event> findbyeventfood(String name);
	
	
	
}
