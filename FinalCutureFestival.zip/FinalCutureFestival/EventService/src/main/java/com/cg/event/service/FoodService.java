package com.cg.event.service;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.cg.event.entity.Food;

public interface FoodService {

	List<Food> fetchall();

	Food add(Food food) throws AddressException, MessagingException, IOException;

	Food update(Food food) throws AddressException, MessagingException, IOException;

	List<Food> delete(Long id);

	List<Food> findbyname(String name);

	List<Food> findbytype(String type);

	List<Food> findbycategory(String Category);

}
