package com.cg.participants.serviceimplementation;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.participants.entity.Participant;
import com.cg.participants.exception.InvalidParticipantIdException;
import com.cg.participants.repository.ParticipantRepository;
import com.cg.participants.service.ParticipantService;

@Service
public class ParticipantServiceImpl implements ParticipantService {

	@Autowired
	private ParticipantRepository participantRepository;

	@Override
	public List<Participant> fetchAllParticipants() {
		return participantRepository.findAll();
	}

	@Override
	public Participant getParticipantById(long participantId) {

		return participantRepository.findById(participantId).orElseThrow(() -> new InvalidParticipantIdException("productOrderId", "Not found"));
	}

	@Override
	public Participant updateParticipant(Participant participant) {
		return participantRepository.save(participant);
	}

	@Override
	public Map<String,String> addParticipant(Participant participant) {

		return Collections.singletonMap("participantId:", participantRepository.save(participant).getParticipantId().toString());
	}

}
