package com.cg.food.controller;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.food.entity.Food;
import com.cg.food.service.FoodService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/food/")
@CrossOrigin(origins = "*")
@Api(value = "Food Service for CulturoFesto using logger and swagger")
public class FoodController {

	@Autowired
	FoodService service;

	@GetMapping("findall")
	@ApiOperation(value = "findall", nickname = "findall")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Food.class),
			@ApiResponse(code = 500, message = "Failure", response = Food.class) })
	public List<Food> findall() {
		return service.fetchall();
	}

	@PostMapping("foodadd")
	@ApiOperation(value = "add", nickname = "add")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Food.class),
			@ApiResponse(code = 500, message = "Failure", response = Food.class) })
	public Food add(@RequestBody Food food) throws AddressException, MessagingException, IOException {
		return service.add(food);
	}
	
	@PutMapping("update")
	@ApiOperation(value = "update", nickname = "update")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Food.class),
			@ApiResponse(code = 500, message = "Failure", response = Food.class) })
	public Food update(@RequestBody Food food) throws AddressException, MessagingException, IOException {
		return service.update(food);
	}
	
	@DeleteMapping("Delete/{id}")
	@ApiOperation(value = "delete", nickname = "delete")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Food.class),
			@ApiResponse(code = 500, message = "Failure", response = Food.class) })
	public List<Food> delete(@PathVariable long id){
		return service.delete(id);
	}
	
	@GetMapping("findbytype/{type}")
	@ApiOperation(value = "findbytype", nickname = "findbytype")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Food.class),
			@ApiResponse(code = 500, message = "Failure", response = Food.class) })
	public List<Food> findbytype(@PathVariable String type){
		return service.findbytype(type);
	}
	
	@GetMapping("findbycategory/{category}")
	@ApiOperation(value = "findbycategory", nickname = "findbycategory")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Food.class),
			@ApiResponse(code = 500, message = "Failure", response = Food.class) })
	public List<Food> findbycategory(@PathVariable String category){
		return service.findbycategory(category);
	}
	
	@GetMapping("findbyname/{name}")
	@ApiOperation(value = "findbyname", nickname = "findbyname")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Food.class),
			@ApiResponse(code = 500, message = "Failure", response = Food.class) })
	public List<Food> findbyname(@PathVariable String name){
		return service.findbyname(name);
	}
	
}
