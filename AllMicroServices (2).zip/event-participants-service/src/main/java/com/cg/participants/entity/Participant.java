package com.cg.participants.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.micrometer.core.lang.NonNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Participant {

	@Id
	@SequenceGenerator(name = "participant_id_sequence", initialValue = 100000, allocationSize = 1)
	@GeneratedValue(generator = "participant_id_sequence", strategy = GenerationType.SEQUENCE)
	@NonNull
	@Min(100000)
	@Max(999999)
	private Long participantId;
	@NotNull
	@Size(min = 5, max = 50)
	private String participantName;
	@NotBlank
	@Size(min = 10, max = 10, message = "Length of phone number must be 10")
	private String participantMobileNo;
	@NotNull
	@Min(10)
	@Max(80)
	private int participantAge;

	@ManyToOne
	@JoinColumn(name = "foodId", referencedColumnName = "foodId", foreignKey = @ForeignKey(name = "FK_food_participant_ID"))
	private Food food;
}
