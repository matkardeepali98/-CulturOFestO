package com.cg.participants;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventParticipantsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventParticipantsServiceApplication.class, args);
	}

}
