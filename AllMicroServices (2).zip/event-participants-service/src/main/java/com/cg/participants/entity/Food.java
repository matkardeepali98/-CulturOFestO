package com.cg.participants.entity;

import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Food {
	

	  @Id
	  @SequenceGenerator(name = "food_id_sequence", initialValue = 100000, allocationSize = 1)
	  @GeneratedValue(generator = "food_id_sequence", strategy = GenerationType.SEQUENCE)
	  private Long foodId;
	  private String foodName;
	  private Double foodPrice;
	  private String foodCategory;
	  private String foodType;
	  
	
}
