package com.cg.participants.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.participants.entity.Participant;

public interface ParticipantRepository extends JpaRepository<Participant, Long> {

}
