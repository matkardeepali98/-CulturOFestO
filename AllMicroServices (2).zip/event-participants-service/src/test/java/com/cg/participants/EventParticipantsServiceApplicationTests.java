package com.cg.participants;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventParticipantsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
