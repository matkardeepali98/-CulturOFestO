package com.cg.event.exceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.cg.event.exception.EmptyListException;
import com.cg.event.exception.NoValueFoundException;
import com.cg.event.exception.NotPossibleException;

@RestController
@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value = NoValueFoundException.class)
	public ResponseEntity<Object> handlingNoValueFoundException(NoValueFoundException e, WebRequest req) {
		HttpStatus status = HttpStatus.NOT_FOUND;
		ApiError error = new ApiError(e.getMessage(),status);
		return new ResponseEntity<>(error, status);
	}

	@ExceptionHandler(value = NotPossibleException.class)
	public ResponseEntity<Object> handlingNotPossibleException(NotPossibleException e, WebRequest req) {
		HttpStatus status = HttpStatus.BAD_REQUEST;
		ApiError error = new ApiError(e.getMessage(),status);
		return new ResponseEntity<>(error, status);
	}

	@ExceptionHandler({ EmptyListException.class })
	public final ResponseEntity<Object> handleEmptyListException(EmptyListException e, WebRequest req) {
		
		ApiError error = new ApiError(e.getMessage(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ApiError> handleValidationExceptions(MethodArgumentNotValidException e, WebRequest req) {
		HttpStatus status = HttpStatus.BAD_REQUEST;
		ApiError error = new ApiError(e.getLocalizedMessage(),status);
		return new ResponseEntity<>(error, status);
	}
}
