package com.cg;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.beans.Customer;
import com.cg.beans.Login;

import com.cg.exception.NullCustomerException;
import com.cg.service.LoginService;
import com.cg.service.LoginServiceImpl;



@SpringBootTest
class LoginApplicationTests {

	@Test
	void contextLoads() {
	}
	
	
	@Test
	void addLoginTest() throws AddressException, MessagingException, IOException, NullCustomerException {
		Customer customer=new Customer("Deepali Matkar",23,"9168494533","deep@gmail.com");
		Login login=new Login("Deepali","Deepali1","Sunita",customer);
		LoginService service=mock(LoginServiceImpl.class);
		when(service.addLogin(login)).thenReturn(login);
		
		Login login2=service.addLogin(login);
		assertEquals(login,login2);
		
	}
	
	@Test
	void updatePassword() throws NullCustomerException, AddressException, MessagingException, IOException  {
		Customer customer=new Customer("Deepali Matkar",23,"9168494533","deep@gmail.com");
		Login login=new Login("Deepali","Deepali1","Sunita",customer);
		
		LoginService service=mock(LoginServiceImpl.class);
		service.addLogin(login);
		service.changepass("Deepali", "Deepali1",false );
		Login login2=new Login("Deepali","Deepali2","Sunita",customer);
		
		when(service.changepass("Deepali", "Deepali2", false)).thenReturn(login2);
		
		Login login3=service.changepass("Deepali", "Deepali2", false);
		assertEquals(login2,login3);
		
	}
	
	
	
	
}
