package com.cg.food.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.food.entity.Food;
import com.cg.food.exception.NoValueFoundException;
import com.cg.food.repository.FoodRepository;

@Service
public class FoodServiceImpl implements FoodService {

	@Autowired
	private FoodRepository repo;

	private static final Logger logger = LoggerFactory.getLogger(FoodServiceImpl.class);

	private void sendmail(String Name, String Type, String category)
			throws AddressException, MessagingException, IOException {

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.googlemail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("healthcaresystem12@gmail.com", "hcs@1234");
			}
		});
		Message msg = new MimeMessage(session);
		msg.setFrom(new InternetAddress("healthcaresystem12@gmail.com", false));

		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("sarkar.sulekha2013@gmail.com"));
		msg.setSubject("Approval  email");
		msg.setContent("Your food is Listed for The Fest with Name:" + Name + ", for:" + Type + ", with category :"
				+ category, "text/html");
		msg.setSentDate(new Date());

		MimeBodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setContent("Your food is Listed for The Fest with Name:" + Name + ", for:" + Type
				+ ", with category :" + category, "text/html");
		// Transport.send(msg);

		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(messageBodyPart);
		MimeBodyPart attachPart = new MimeBodyPart();

		attachPart.attachFile("C:\\Users\\sharm\\OneDrive\\Pictures\\Screenshots\\2017-08-31.png");
		multipart.addBodyPart(attachPart);
		msg.setContent(multipart);
		Transport.send(msg);
	}
	
	@Override
	public List<Food> fetchall() {
		return repo.findAll();
	}

	@Override
	public Food add(Food food) throws AddressException, MessagingException, IOException {
		logger.info("Food Added into Database");
		System.out.println(food);
		sendmail(food.getName(),food.getType(),food.getCategory());
		return repo.save(food);
	}

	@Override
	public Food update(Food food) throws AddressException, MessagingException, IOException {
		logger.info("Update Complete");
		sendmail(food.getName(),food.getType(),food.getCategory());
		return this.repo.save(food);
	}

	@Override
	public List<Food> delete(Long id) {
		repo.deleteById(id);
		logger.info("Delete Successful");
		return repo.findAll();
	}

	@Override
	public List<Food> findbyname(String name) {
		List<Food> food = new ArrayList<>();
		for (Food f : repo.findAll()) {
			if (f.getType().equalsIgnoreCase(name))
				food.add(f);
		}
		if (food.isEmpty()) {
			logger.warn("No data Found for this name");
			throw new NoValueFoundException("No food Found for this Name");
		}else
			return food;
	}

	@Override
	public List<Food> findbytype(String type) {
		List<Food> food = new ArrayList<>();
		for (Food f : repo.findAll()) {
			if (f.getType().equalsIgnoreCase(type))
				food.add(f);
		}
		if (food.isEmpty()) {
			logger.warn("No data Found for this type");
			throw new NoValueFoundException("No food Found for this type");
		}else
			return food;
	}

	@Override
	public List<Food> findbycategory(String Category) {
		List<Food> food = new ArrayList<>();
		for (Food f : repo.findAll()) {
			if (f.getType().equalsIgnoreCase(Category))
				food.add(f);
		}
		if (food.isEmpty()) {
			logger.warn("No data Found for this category");
			throw new NoValueFoundException("No food Found for this category");
			
		} else
			return food;
	}
}
