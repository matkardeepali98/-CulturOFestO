package com.cg.bookevent.service;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bookevent.dao.BookEventDao;
import com.cg.bookevent.entity.BookEvent;
import com.cg.bookevent.entity.Customer;
import com.cg.bookevent.entity.Food;
import com.cg.bookevent.entity.Participant;
import com.cg.bookevent.exception.BookEventNotFoundException;
import com.cg.bookevent.exception.EmptyListException;
import com.cg.bookevent.exception.NullEventException;
import com.twilio.Twilio;
import com.twilio.type.PhoneNumber;

/**
 * 
 * @author Shubham Sharma
 *
 */
@Service
public class BookEventService {
	
	@Autowired
	BookEventDao book;
	
	public BookEvent addEvent(BookEvent event) throws NullEventException {
		if(event.getStatus() == null)
			throw new NullEventException("Null Value");
		else
		return book.save(event);

	}

	public BookEvent SearchBookedEvent(Integer id) throws BookEventNotFoundException {
		
		return book.findById(id).orElseThrow(() -> new BookEventNotFoundException("Booking for this Event i : "+id+" Not Found"));

	}

	public List<BookEvent> listBookedEvents() throws EmptyListException {
		List<BookEvent> bookeventlist =  book.findAll();
		if(bookeventlist.isEmpty())
			throw new EmptyListException("No Bookings Till Yet!!");
		return bookeventlist;

	}
	
	public List<BookEvent> listBookedEventsbasedcustomers(Customer cust) throws EmptyListException {
		
		List<BookEvent> bookeventlist =  book.findAll();
//		System.out.println(bookeventlist.size());
		List<BookEvent> custbookeventlist =  new ArrayList<BookEvent>();
		for (BookEvent bookEvent : bookeventlist) {
			if(bookEvent.getCustomer().getCustId() == cust.getCustId())
//				System.out.println("Inside if");
//				System.out.println(bookEvent);
				custbookeventlist.add(bookEvent);
			
		}
		System.out.println("Outside for");
		System.out.println(custbookeventlist.size());
		if(custbookeventlist.isEmpty())
			throw new EmptyListException("No Bookings Till Yet!!");
		return custbookeventlist;

	}
	
	public void deleteEvent(Integer id) {
		 book.deleteById(id);

	}
	
//	public void export(Integer id) throws IOException {
//		for (BookEvent event : book.findAll()) {
//			if (event.getBookId() == id) {
//				
//				Integer i = 1;
//				
//				Writer writer = new FileWriter("G:/capgemini/"
//						+ event.getCustomer().getCustName() + " " + event.getEvent().getName() +"("+ i +")" + ".csv");
//				i++;
//				writer.write("CustName,MobileNo,EventName,venue,StartDate,EndDate,No. of Participants,Status\n");
//				writer.write(event.getCustomer().getCustName() + "," + event.getCustomer().getMobile() + ","
//						+ event.getEvent().getName() + "," + event.getEvent().getVenue() + ","
//						+ event.getEvent().getDateFrom() + "," + event.getEvent().getDateTo() + ","
//						+ event.getParticipants().size() + "," + "Booked");
//
//				writer.close();
//				
//			}
//
//		}
//
//	}
	public void export(Integer id) throws IOException {
		for (BookEvent event : book.findAll()) {
			if (event.getBookId() == id) {
			int i=LocalDateTime.now().getSecond();
				Writer writer = new FileWriter("G:/capgemini/"
						+ event.getCustomer().getCustName() + " " + event.getEvent().getName()+ i + ".csv");
				writer.write("CustName,MobileNo,EventName,venue,StartDate,EndDate,No. of Participants,Status\n");
				writer.write(event.getCustomer().getCustName() + "," + event.getCustomer().getMobile() + ","
						+ event.getEvent().getName() + "," + event.getEvent().getVenue() + ","
						+ event.getEvent().getDateFrom() + "," + event.getEvent().getDateTo() + ","
						+ event.getParticipants().size() + "," + "Booked");

				writer.close();
			}

		}

	}
	
	private final static String ACCOUNT_SID = "AC6e2b4bd6cc73e90139be1e03b9e0256a";
	private final static String AUTH_ID = "5f36153c4fd10ff603ca0083d6afabe2";

	static {
		Twilio.init(ACCOUNT_SID, AUTH_ID);
	}

	public int sendpaymentotp(String number) throws Exception {
			// create instance of Random class
			Random rand = new Random();

			int rand_int1 = rand.nextInt(1000);
			String s = "+91" + number;
			com.twilio.rest.api.v2010.account.Message.creator(new PhoneNumber(s), new PhoneNumber("+12056711348"),
					"Your otp for payment is : " + rand_int1).create();

			return rand_int1;
		}
	
	public double calculateAmount(BookEvent event) {
		double sum = 0;
		Integer l = event.getParticipants().size();
		sum = sum + (event.getEvent().getPrice()*l);
		for (Participant participant : event.getParticipants()) {
			if(participant.getFoods().isEmpty())
				continue;
			for (Food food : participant.getFoods()) {
				sum = sum + food.getPrice();
			}
		}
		
		return sum;
	}
	
}


