package com.cg.event.controller;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.event.entity.Event;
import com.cg.event.entity.Food;
import com.cg.event.exception.EmptyListException;
import com.cg.event.service.EventService;

import io.swagger.annotations.Api;

@RestController
@RequestMapping("/event/")
@CrossOrigin(origins = "http://localhost:4200")
@Api(value = "Event Service for CulturoFesto using logger and swagger")
public class EventController {

	@Autowired
	EventService service;
	
	private static final String QR_CODE_IMAGE_PATH = "./src/main/resources/QRCode.png";
	
	@GetMapping("findall")
	public List<Event> findall() throws EmptyListException{
		return service.fetchall();
	}
	
	@PostMapping("add")
	public Event add(@RequestBody Event event) throws AddressException, MessagingException, IOException {
		return service.addevent(event);
	}
	
	@PostMapping("update")
	public Event update(@RequestBody Event event) throws AddressException, MessagingException, IOException {
		return service.update(event);
	}
	
	@DeleteMapping("Delete/{id}")
	public List<Event> delete(@PathVariable long id){
		return service.delete(id);
	}
	/////////////////////////QRCode
	 @GetMapping(value = "/qrcode/{barcode}", produces = MediaType.IMAGE_PNG_VALUE)
	    public BufferedImage barbecueEAN13Barcode(@PathVariable("barcode") String barcode)
	    throws Exception {
	        return service.generateQRCodeImage(barcode);
	    }
	 
	 @GetMapping(value = "/genrateAndDownloadQRCode/{codeText}")
		public void download(
				@PathVariable("codeText") String codeText)
			    throws Exception {
			        service.generateQRCodeImage(codeText, QR_CODE_IMAGE_PATH);
			    }

 @GetMapping(value = "/genrateQRCode/{codeText}")
	public ResponseEntity<byte[]> generateQRCode(
			@PathVariable("codeText") String codeText)
		    throws Exception {
		        return ResponseEntity.status(HttpStatus.OK).body(service.getQRCodeImage(codeText));
		    }
	
	@GetMapping("list/{id}")
	public List<Food> getList(
			@PathVariable("id") Long id)
	{
		return this.service.listfood(id);
	}
	
	   @GetMapping("findbyid/{id}")
		public Event geteventbyid(@PathVariable("id") Long id) {
			return this.service.findbyid(id);
		}
		
		@GetMapping("findbyname/{name}")
		public List<Event> geteventbyname(@PathVariable("name") String name) {
			return this.service.findbyname(name);
		}
		
		@GetMapping("findbyvenue/{venue}")
		public List<Event> geteventbyvenue(@PathVariable("venue") String venue) {
			return this.service.findbyvenue(venue);
		}
		
		@GetMapping("findbyeventfood/{name}")
		public List<Event> geteventbyeventfood(@PathVariable("name") String name) {
			return this.service.findbyeventfood(name);
		}
}
