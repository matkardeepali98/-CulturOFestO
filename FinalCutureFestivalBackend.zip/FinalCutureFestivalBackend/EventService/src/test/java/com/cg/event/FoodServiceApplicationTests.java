package com.cg.event;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.event.entity.Food;
import com.cg.event.service.FoodService;
import com.cg.event.service.FoodServiceImpl;

@SpringBootTest
class FoodServiceApplicationTests {

	@Test
	void contextLoads() {
	}
	
	@Test
	void addFoodTest() throws AddressException, MessagingException, IOException {
		Food food=new Food("Bature",12.0,"Adult","Lunch");
		FoodService foodService=mock(FoodServiceImpl.class);
		when(foodService.add(food)).thenReturn(food);
		
		Food food2=foodService.add(food);
		assertEquals(food,food2);
		
	}
	
	@Test
	void updateFoodTest() throws AddressException, MessagingException, IOException {
		Food food=new Food("Bature",12.0,"Adult","Lunch");
		FoodService foodService=mock(FoodServiceImpl.class);
		foodService.add(food);
		Food food2=new Food("Chole Bature",12.0,"Adult","Lunch");
		
		
		when(foodService.update(food2)).thenReturn(food2);
		
		Food food3=foodService.update(food2);
		assertEquals(food2,food3);
		
	}
	
	@Test
	void findAllFood() {
		List<Food> food=new ArrayList<>();
		Food food1=new Food("Bature",70.0,"Adult","Lunch");
		Food food2=new Food("Rice",60.0,"Adult","Lunch");
		Food food3=new Food("Daal",50.0,"Adult","Lunch");
		
		food.add(food1);
		food.add(food2);
		food.add(food3);
		
		FoodService foodService=mock(FoodServiceImpl.class);
		when(foodService.fetchall()).thenReturn(food);
		List<Food> foodlist=foodService.fetchall();
		assertNotNull(foodlist);
		assertFalse(foodlist.isEmpty());
	
	}
	
	@Test
	void findByType() {
		List<Food> food=new ArrayList<>();
		Food food1=new Food("Bature",70.0,"Adult","Lunch");
		Food food2=new Food("Rice",60.0,"Adult","Lunch");
		Food food3=new Food("Daal",50.0,"Kid","Lunch");
		
		food.add(food1);
		food.add(food2);
		food.add(food3);
		
		FoodService foodService=mock(FoodServiceImpl.class);
		when(foodService.findbytype("Kid")).thenReturn(food);
		List<Food> foodlist=foodService.findbytype("Kid");
		assertNotNull(foodlist);
		assertFalse(foodlist.isEmpty());
	
	}
	
	@Test
	void deleteFood() {
		List<Food> food=new ArrayList<>();
		Food food1=new Food("Bature",70.0,"Adult","Lunch");
		Food food2=new Food("Rice",60.0,"Adult","Lunch");
		Food food3=new Food("Daal",50.0,"Kid","Lunch");
		
		food.add(food1);
		food.add(food2);
		food.add(food3);
		
		FoodService foodService=mock(FoodServiceImpl.class);
		when(foodService.delete(6L)).thenReturn(food);
		List<Food> foodlist=foodService.delete(6L);
		assertNotNull(foodlist);
		assertFalse(foodlist.isEmpty());
	
	}
	
	

}
