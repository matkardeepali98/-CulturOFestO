package com.cg.bookevent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 
 * @author Shubham Sharma
 */
@SpringBootTest
class FestBookedEventMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
