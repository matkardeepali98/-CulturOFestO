import { Component, OnInit,VERSION } from '@angular/core';
import  jspdf from 'jspdf';    
import html2canvas from 'html2canvas'; 
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentInfo } from '../model/paymentinfo';
import { Customer } from '../model/customer';
import { LoginserviceService } from '../Services/loginservice.service';
import { NgxQrcodeElementTypes, NgxQrcodeErrorCorrectionLevels } from 'ngx-qrcode2';
import { BookeventserviceService } from '../Services/bookeventservice.service';
import { BookEvent } from '../model/bookevent';


@Component({
  selector: 'app-bookingdetailspdf',
  templateUrl: './bookingdetailspdf.component.html',
  styleUrls: ['./bookingdetailspdf.component.css']
})
export class BookingdetailspdfComponent implements OnInit {
  bookedEvent :BookEvent;
  paymentInfo:PaymentInfo;
  customer:Customer;
  amount : number;
  title = 'app';
  name= 'Angular' +VERSION.major;
  elementType = NgxQrcodeElementTypes.URL;
  value : string;
  correctionLevel = NgxQrcodeErrorCorrectionLevels.HIGH;
  constructor(private route:ActivatedRoute,private router:Router,private loginService:LoginserviceService,private bookEventService:BookeventserviceService) { 
    this.paymentInfo=new PaymentInfo();
    this.customer=new Customer();
    this.paymentInfo.eventName=this.route.snapshot.paramMap.get("name");
    this.paymentInfo.eventVenue=this.route.snapshot.paramMap.get("venue");
    this.paymentInfo.eventDate=this.route.snapshot.paramMap.get("dateFrom");
    this.customer=this.loginService.getcustinfo();
  }

  ngOnInit() {
    this.bookedEvent = this.bookEventService.fetchfinalbookevent();
this.amount = this.bookEventService.getPaymentInfo();
    this.value = "Your Event Name is " +this.bookedEvent.event.name + " with event id " +this.bookedEvent.event.eventId + " And Your Entries are " + this.bookedEvent.participants.length + " \nThank You For Using Our Service";
  }


  public captureScreen()  
  {  
    var data = document.getElementById('contentToConvert');  
    html2canvas(data).then(canvas => {  
      // Few necessary setting options  
      var imgWidth = 208;   
      var pageHeight = 295;    
      var imgHeight = canvas.height * imgWidth / canvas.width;  
      // var imgHeight=400;
      var heightLeft = imgHeight;  
  
      const contentDataURL = canvas.toDataURL('image/png')  
      let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF  
      var position = 0;  
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)  
      pdf.save('Eventro.pdf'); // Generated PDF   
    });  

    this.router.navigate(['/customerdashboard/home']);
  } 
}