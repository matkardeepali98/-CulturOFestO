import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingdetailspdfComponent } from './bookingdetailspdf.component';

describe('BookingdetailspdfComponent', () => {
  let component: BookingdetailspdfComponent;
  let fixture: ComponentFixture<BookingdetailspdfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingdetailspdfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingdetailspdfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
