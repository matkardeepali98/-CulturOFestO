import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookEvent } from '../model/bookevent';
import { BookeventserviceService } from '../Services/bookeventservice.service';
import { ParticipantserviceService } from '../Services/participantservice.service';

@Component({
  selector: 'app-paymentconfirmation',
  templateUrl: './paymentconfirmation.component.html',
  styleUrls: ['./paymentconfirmation.component.css']
})
export class PaymentconfirmationComponent implements OnInit {

  finalBookedEvent : BookEvent;
  bookedOtp:number;
  userOtp:number;
  dummyOtp:string;
  constructor(private router:Router, private bookeventservice : BookeventserviceService, private participantservice : ParticipantserviceService) { }

  ngOnInit() {
  }


  onSubmit(){
    this.bookedOtp=this.bookeventservice.getLocallySaveOtp();
    console.log("in confrimation"+this.bookedOtp);
    if(Number(this.dummyOtp)==Number(this.userOtp)){
      if(this.bookedOtp==Number(this.dummyOtp)){
    this.bookeventservice.addbook().subscribe((r : BookEvent) => {
      this.finalBookedEvent = r;
      this.bookeventservice.savingfinalbookevent(this.finalBookedEvent);
      this.participantservice.clear();
      this.router.navigate(["../customerdashboard/qrcode"]);
    })
  }
  else
  alert("You entered the wrong otp");
  }
  else
  alert("Please enter same otp!!");
}


  
}
