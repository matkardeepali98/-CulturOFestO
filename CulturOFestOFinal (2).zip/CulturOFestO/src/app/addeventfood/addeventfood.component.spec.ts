import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddeventfoodComponent } from './addeventfood.component';

describe('AddeventfoodComponent', () => {
  let component: AddeventfoodComponent;
  let fixture: ComponentFixture<AddeventfoodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddeventfoodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddeventfoodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
