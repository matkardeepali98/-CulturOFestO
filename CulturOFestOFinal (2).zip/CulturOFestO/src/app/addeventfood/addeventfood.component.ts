import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Food } from '../model/food.model';
import { EventserviceService } from '../Services/eventservice.service';
import { FoodserviceService } from '../Services/foodservice.service';

@Component({
  selector: 'app-addeventfood',
  templateUrl: './addeventfood.component.html',
  styleUrls: ['./addeventfood.component.css']
})
export class AddeventfoodComponent implements OnInit {

  foodlist : Food[];
  flag = false;
  constructor(private service : FoodserviceService, private eventservice : EventserviceService) { }

  ngOnInit() {
    this.service.fetchFood().subscribe((r) => { this.foodlist = r;
      if(this.foodlist === [])
      this.flag = false;
    this.flag = true;
    
  },err => {
     if (err instanceof HttpErrorResponse) {
       if (err.status === 404) { 
         this.flag = false;
         
         window.alert("There are no Foods!!!");
       }
     }
   });
  }

  delete(id: number){
    this.service.deleteFoodById(id);
  }

  add(food : Food){
    this.eventservice.savefoodinevent(food);
  }
 


}
