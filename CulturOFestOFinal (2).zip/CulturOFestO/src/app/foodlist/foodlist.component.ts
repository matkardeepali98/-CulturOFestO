import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Food } from '../model/food.model';
import { FoodserviceService } from '../Services/foodservice.service';

@Component({
  selector: 'app-foodlist',
  templateUrl: './foodlist.component.html',
  styleUrls: ['./foodlist.component.css']
})
export class FoodlistComponent implements OnInit {

  foodlist : Food[];
  flag = false;
  foodName: string;
  constructor(private service : FoodserviceService) { }

  ngOnInit() {
    this.service.fetchFood().subscribe((r) => { this.foodlist = r;
      if(this.foodlist === [])
      this.flag = false;
    this.flag = true;
    
  },err => {
     if (err instanceof HttpErrorResponse) {
       if (err.status === 404) { 
         this.flag = false;
         
         window.alert("There are no Foods!!!");
       }
     }
   });
  }

  delete(id: number){
    this.service.deleteFoodById(id);
  }
  search(){
    if(this.foodName != ""){
    this.foodlist = this.foodlist.filter(res=>{
     return res.name.toLocaleLowerCase().match(this.foodName.toLocaleLowerCase());
    })
  }else if(this.foodName ==""){
    this.ngOnInit();
  }
  }
}
