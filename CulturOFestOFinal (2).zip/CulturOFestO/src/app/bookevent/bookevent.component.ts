// import { Component, OnInit } from '@angular/core';
// import { BookEvent } from '../model/bookevent';
// import { ActivatedRoute, Router } from '@angular/router';
// import { Event } from '../model/event.model';
// import { BookeventserviceService } from '../Services/bookeventservice.service';
// import { EventserviceService } from '../Services/eventservice.service';

// @Component({
//   selector: 'app-bookevent',
//   templateUrl: './bookevent.component.html',
//   styleUrls: ['./bookevent.component.css']
// })
// export class BookeventComponent implements OnInit {
// bookingEvent: Event;
//   event:Event;
//   bookEvent:BookEvent;
//   constructor(private route:ActivatedRoute,private router:Router,private bookEventService:BookeventserviceService,private eventService:EventserviceService ) {
//     this.event=new Event();
//     this.bookEvent=new BookEvent();
//     this.event.eventId=parseInt(this.route.snapshot.paramMap.get("eventId"));
//     this.bookingEvent = this.eventService.gettempEvent();
//     this.event.name=this.route.snapshot.paramMap.get("name");
//     this.event.price=parseInt(this.route.snapshot.paramMap.get("price"));
//    }

//   ngOnInit() {
    
//   }

//   addEntry(){
//     this.router.navigate(['/customerdashboard/addParticipant',this.event]);
//   }

//   onSubmit(){
//     this.bookEventService.saveonlocal(this.eventService.gettempEvent());
//     this.router.navigate(['/customerdashboard/payment']);
//   }
// }

import { Component, OnInit } from '@angular/core';
import { BookEvent } from '../model/bookevent';
import { ActivatedRoute, Router } from '@angular/router';
import { Event } from '../model/event.model';
import { BookeventserviceService } from '../Services/bookeventservice.service';
import { EventserviceService } from '../Services/eventservice.service';
import { ParticipantserviceService } from '../Services/participantservice.service';
import { Participant } from '../model/Participant';
import { LoginserviceService } from '../Services/loginservice.service';
import { Food } from '../model/food.model';
 
@Component({
  selector: 'app-bookevent',
  templateUrl: './bookevent.component.html',
  styleUrls: ['./bookevent.component.css']
})
export class BookeventComponent implements OnInit {
bookingEvent: Event;
  event:Event;
  bookEvent:BookEvent;
  partFoods : Food[];
  participantlist : Participant[];
  totalPrice:number;
  samplepartFoods : Food[];
  foodPrice : number;
  constructor(private route:ActivatedRoute,private router:Router,private bookEventService:BookeventserviceService,private eventService:EventserviceService,private participantService:ParticipantserviceService, private loginservice : LoginserviceService ) {
    this.event=new Event();
    this.bookEvent=new BookEvent();
    this.event.eventId=parseInt(this.route.snapshot.paramMap.get("eventId"));
    this.bookingEvent = this.eventService.gettempEvent();
    this.event.name=this.route.snapshot.paramMap.get("name");
    this.event.price=parseInt(this.route.snapshot.paramMap.get("price"));
   }
 
  ngOnInit() {
    this.participantlist = this.participantService.fetchparticipant();
    //this.partFoods = 
  }
 
  addEntry(){
    this.router.navigate(['/customerdashboard/addParticipant',this.event]);
  }
 
  onSubmit(){
if(this.participantService.fetchparticipant().length == 0){
alert("Without Add Participant You Can't go forward");
this.router.navigate(['../customerdashboard/bookevent']);
}else{

    this.bookEvent.event = this.eventService.gettempEvent();
    this.bookEvent.customer = this.loginservice.getcustinfo();
    this.bookEvent.participants = this.participantService.fetchparticipant();
    this.bookEvent.status = "booked";
    this.bookEventService.saveonlocal(this.bookEvent);
    
    
  //   for(var i = 0; i<this.participantlist.length;i++){
  //     for(var j = 0; i<this.participantlist[i].foods.length;j++)
  //     this.samplepartFoods[i+1] = this.participantlist[i].foods[j];
  // }
  
  // for(var i = 0; i<this.samplepartFoods.length;i++){
// this.foodPrice = this.foodPrice + this.samplepartFoods[i].price;
//   }



// this.samplepartFoods = this.eventService.gettempfoodlist();
// this.foodPrice = 0;
// if(this.samplepartFoods[0].name != undefined){
// for(var i = 0; i<this.samplepartFoods.length;i++){
// this.foodPrice = this.foodPrice + this.samplepartFoods[i].price;
//   }
//   console.log(this.foodPrice);
//   this.totalPrice=(this.event.price*(this.participantlist.length) ) + this.foodPrice;
//   console.log(this.totalPrice);
// }else{
//   this.totalPrice=(this.event.price*(this.participantlist.length) ) ;
// }
this.bookEventService.getPrice(this.bookEvent).subscribe((r : number) => {
  this.totalPrice = r;
  this.bookEventService.savePaymentLocally(this.totalPrice);
  this.router.navigate(['/customerdashboard/payment']);
})

     
  }
  }
 
  delete(part : Participant){
    for(var i=0;i<this.participantlist.length;i++){
      if(part.participantMobileNo == this.participantlist[i].participantMobileNo){
        console.log(this.participantlist[i]);
        this.participantlist.splice(i,1);
        break;
      }
    }
  }
}
