import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { AddfoodComponent } from './addfood/addfood.component';
import { AddeventComponent } from './addevent/addevent.component';
import { EventlistComponent } from './eventlist/eventlist.component';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { SignupComponent } from './signup/signup.component';
import { LoginbannerComponent } from './loginbanner/loginbanner.component';
import { LoginComponent } from './login/login.component';
import { ResetComponent } from './reset/reset.component';
import { MybookingsComponent } from './mybookings/mybookings.component';
import { CustomerdashboardComponent } from './customerdashboard/customerdashboard.component';
import { CusteventlistComponent } from './custeventlist/custeventlist.component';
import { MyaccountComponent } from './myaccount/myaccount.component';
import { BookeventComponent } from './bookevent/bookevent.component';
import { AddParticipantComponent } from './add-participant/add-participant.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentconfirmationComponent } from './paymentconfirmation/paymentconfirmation.component';
import { QrcodeComponent } from './qrcode/qrcode.component';
import {NgxQRCodeModule} from 'ngx-qrcode2';
import { HomeComponent } from './home/home.component';
import { FoodlistComponent } from './foodlist/foodlist.component';
import { AddeventfoodComponent } from './addeventfood/addeventfood.component';
import { ParticipantlistComponent } from './participantlist/participantlist.component';
import { ContactusComponent } from './contactus/contactus.component';
import { SearchcontentComponent } from './searchcontent/searchcontent.component';
import { BookingdetailspdfComponent } from './bookingdetailspdf/bookingdetailspdf.component';

@NgModule({
  declarations: [
    AppComponent,
    AdmindashboardComponent,
    AddfoodComponent,
    AddeventComponent,
    EventlistComponent,
    SignupComponent,
    LoginbannerComponent,
    LoginComponent,
    ResetComponent,
    CustomerdashboardComponent,
    CusteventlistComponent,
    MyaccountComponent,
    BookeventComponent,
    MybookingsComponent,
    AddParticipantComponent,
    PaymentComponent,
    PaymentconfirmationComponent,
    QrcodeComponent,
    HomeComponent,
    FoodlistComponent,
    AddeventfoodComponent,
    ParticipantlistComponent,
    ContactusComponent,
    SearchcontentComponent,
    BookingdetailspdfComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    NgxQRCodeModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
