import { Component, OnInit, VERSION } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxQrcodeElementTypes, NgxQrcodeErrorCorrectionLevels } from 'ngx-qrcode2';
import { BookEvent } from '../model/bookevent';
import { BookeventserviceService } from '../Services/bookeventservice.service';

@Component({
  selector: 'app-qrcode',
  templateUrl: './qrcode.component.html',
  styleUrls: ['./qrcode.component.css']
})
export class QrcodeComponent implements OnInit {
bookedEvent :BookEvent;
  title = 'app';
  name= 'Angular' +VERSION.major;
  elementType = NgxQrcodeElementTypes.URL;
  value : string;
  totalPayment : number;
  correctionLevel = NgxQrcodeErrorCorrectionLevels.HIGH;
  // value = "Your Event Name is " +this.bookedEvent.event.name + " ";
  constructor(private router:Router,private route: ActivatedRoute, private bookeventservice : BookeventserviceService) { 
    
  }
  

  ngOnInit() {
    this.bookedEvent = this.bookeventservice.fetchfinalbookevent();
    this.totalPayment = this.bookeventservice.getPaymentInfo();
    this.value = "Your Event Name is " +this.bookedEvent.event.name + " with event id " +this.bookedEvent.event.eventId + " And Your Entries are " + this.bookedEvent.participants.length + " \nThank You For Using Our Service";
  }

  
}
