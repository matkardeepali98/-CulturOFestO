import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookeventserviceService } from '../Services/bookeventservice.service';
import { EventserviceService } from '../Services/eventservice.service';
import { FoodserviceService } from '../Services/foodservice.service';
import { LoginserviceService } from '../Services/loginservice.service';
import { ParticipantserviceService } from '../Services/participantservice.service';

@Component({
  selector: 'app-customerdashboard',
  templateUrl: './customerdashboard.component.html',
  styleUrls: ['./customerdashboard.component.css']
})
export class CustomerdashboardComponent implements OnInit {

  constructor(private router : Router,private bookeventservice:BookeventserviceService, private eventservice:EventserviceService, private loginservice:LoginserviceService, private participantservice : ParticipantserviceService) { }

  ngOnInit() {
  }
  logout(){

    this.eventservice.clear();
    this.loginservice.clear();
    this.bookeventservice.clear();
    this.participantservice.clear();
    this.router.navigate(['../loginbanner/login']);
  }
}
