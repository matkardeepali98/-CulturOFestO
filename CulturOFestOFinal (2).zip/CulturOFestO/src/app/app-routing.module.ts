import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AddParticipantComponent } from "./add-participant/add-participant.component";
import { AddeventComponent } from "./addevent/addevent.component";
import { AddeventfoodComponent } from "./addeventfood/addeventfood.component";
import { AddfoodComponent } from "./addfood/addfood.component";
import { AdmindashboardComponent } from "./admindashboard/admindashboard.component";
import { BookeventComponent } from "./bookevent/bookevent.component";
import { BookingdetailspdfComponent } from "./bookingdetailspdf/bookingdetailspdf.component";
import { ContactusComponent } from "./contactus/contactus.component";
import { CusteventlistComponent } from "./custeventlist/custeventlist.component";
import { CustomerdashboardComponent } from "./customerdashboard/customerdashboard.component";
import { EventlistComponent } from "./eventlist/eventlist.component";
import { FoodlistComponent } from "./foodlist/foodlist.component";
import { HomeComponent } from "./home/home.component";
import { LoginComponent } from "./login/login.component";
import { LoginbannerComponent } from "./loginbanner/loginbanner.component";
import { MyaccountComponent } from "./myaccount/myaccount.component";
import { MybookingsComponent } from "./mybookings/mybookings.component";
import { ParticipantlistComponent } from "./participantlist/participantlist.component";
import { PaymentComponent } from "./payment/payment.component";
import { PaymentconfirmationComponent } from "./paymentconfirmation/paymentconfirmation.component";
import { QrcodeComponent } from "./qrcode/qrcode.component";
import { ResetComponent } from "./reset/reset.component";
import { SearchcontentComponent } from "./searchcontent/searchcontent.component";
import { SignupComponent } from "./signup/signup.component";


const routes: Routes = [{
    path: "admindashboard", component: AdmindashboardComponent,
  children: [
    {
      path: "addfood", component: AddfoodComponent
    },
  {
    path: "eventlist", component: EventlistComponent
  },
  {
    path: "addeventfood", component: AddeventfoodComponent
  },
  {
    path: "addevent",component :AddeventComponent,
    children: [
      {
        path: "foodlist", component: FoodlistComponent
      }]
  },
  {
    path: "foodlist", component: FoodlistComponent
  }
]
},
{
path: "loginbanner", component: LoginbannerComponent,
children: [
  {
    path: "login", component: LoginComponent
  },
{
  path: "signup", component: SignupComponent
},
{
  path: "reset", component: ResetComponent
},
{
  path: "contactus", component: ContactusComponent
}

]
},
{
  path: "customerdashboard", component: CustomerdashboardComponent,
children: [
{
  path: "custeventlist", component: CusteventlistComponent
},
{
  path: "myaccount", component: MyaccountComponent
},
{
  path: "bookevent", component: BookeventComponent,
  children: [
    {
      path: "participantlist", component: ParticipantlistComponent
    }]
},
{
  path: "addParticipant", component:AddParticipantComponent
},
{
  path: "payment" , component:PaymentComponent
},
{
  path:"paymentconfirmation" ,component:PaymentconfirmationComponent
},
{
  path:"qrcode" , component:QrcodeComponent
},
{
  path:"home" ,component:HomeComponent
},
{
  path:"mybookings" ,component:MybookingsComponent
},
{
  path: "contactus", component: ContactusComponent
},
{
  path:"searchcontent" ,component:SearchcontentComponent
},
{
  path:"bookingdetailspdf" ,component:BookingdetailspdfComponent
}
]
}];


@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }
  