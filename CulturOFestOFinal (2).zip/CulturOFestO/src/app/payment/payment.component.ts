import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../model/customer';
import { PaymentInfo } from '../model/paymentinfo';
import { BookeventserviceService } from '../Services/bookeventservice.service';
import { LoginserviceService } from '../Services/loginservice.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
otp : number;
customer : Customer;
name:string;
  creditCardNumber:string;
  month:string;
  year:string;
  cvv:string;
  paymentInfo:PaymentInfo;
  totalPayment:number;
  constructor(private router:Router,private bookEventService:BookeventserviceService,private loginService:LoginserviceService) {
    this.paymentInfo=new PaymentInfo();
   this.totalPayment=this.bookEventService.getPaymentInfo();
   }

  ngOnInit() {
  }

  onSubmit(){
    this.customer=this.loginService.getcustinfo();
    this.bookEventService.sendotp(this.customer.mobile).subscribe(data => {
     
      console.log(data);
      this.otp=data; 
      this.bookEventService.saveOtpLocally(this.otp);
    });  
    this.paymentInfo.paymentDate= new Date().toISOString().slice(0,10);
    this.paymentInfo.paymentPrice=this.totalPayment;
    this.router.navigate(['/customerdashboard/paymentconfirmation']);
  }
}
