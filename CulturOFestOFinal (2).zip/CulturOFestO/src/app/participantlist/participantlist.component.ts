import { Component, OnInit } from '@angular/core';
import { Participant } from '../model/Participant';
import { ParticipantserviceService } from '../Services/participantservice.service';

@Component({
  selector: 'app-participantlist',
  templateUrl: './participantlist.component.html',
  styleUrls: ['./participantlist.component.css']
})
export class ParticipantlistComponent implements OnInit {


  participantlist : Participant[];
  flag = false;
  constructor(private service : ParticipantserviceService) { }

  ngOnInit() {
    this.participantlist = this.service.fetchparticipant();
      
    this.flag = true;
    
  }

  delete(id: number){
   // this.service.deleteFoodById(id);
  }

}
