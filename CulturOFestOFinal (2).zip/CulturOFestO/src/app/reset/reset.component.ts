import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Login } from '../model/login';
import { LoginserviceService } from '../Services/loginservice.service';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.css']
})
export class ResetComponent implements OnInit {

  @ViewChild("form") resetform: NgForm;
  login:Login;
  userName:string;
  password:string;
  securityans:string;
  tablediv:boolean;
  bool:boolean;
  otp:number;
  userotp:number;
  
  
  constructor(private router:Router,private loginservice:LoginserviceService) { }

  ngOnInit() {
  }

  onSubmit(){
    console.log("inside onsubmit");
    this.reset(this.userName,this.securityans,this.password);
   
  }

  reset(userName:string,securityans:string,passowrd:string){
   
      console.log("inside reset function");
      console.log(userName);
      console.log(securityans);
    this.loginservice.generateOTP(userName,securityans).subscribe(data => {
     
      console.log(data);
      this.otp=data;
    });  
    this.tablediv=true;
    }

    
    
    
    verify(){

      console.log(this.otp);
      console.log(this.userotp);
      if(this.otp==this.userotp){
        this.bool=true;
      }else{
        this.bool=false;
         alert("Provide Valid OTP");
      }
     
    
      let login=new Login();
      this.loginservice.verifyOTP(this.userName,this.password,this.bool,login).subscribe(
        data=>{
          console.log(data);
           alert("Password Sucessfully reset!!!");
           this.router.navigate(['../loginbanner/login']);
           }
      )

       }
}
