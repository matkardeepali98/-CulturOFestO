import { Component, OnInit } from '@angular/core';
import { Event } from '../model/event.model';
import {  Router } from '@angular/router';
import { Food } from '../model/food.model';
import { EventserviceService } from '../Services/eventservice.service';
import { FoodserviceService } from '../Services/foodservice.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-addevent',
  templateUrl: './addevent.component.html',
  styleUrls: ['./addevent.component.css']
})
export class AddeventComponent implements OnInit {

  event:Event;
  foods:Food[]=[];
  food:Food;
  price:string;
  validationDate = new Date().toISOString().slice(0,10);
  constructor(private router:Router,private foodService:FoodserviceService,private eventService:EventserviceService) { 
    this.event=new Event();
    this.food=new Food();
  }

  ngOnInit() {
   
  }

  onSubmit() {
    console.log("inside onsubmit");
    this.event.price=Number(this.price);
    console.log(this.event);
    
    this.eventService.addEvent(this.event).subscribe((r : Event) => {this.event = r;
      window.alert("Event Added Successfully");
      this.router.navigate(['/admindashboard/eventlist']);
    },err => {
      if (err instanceof HttpErrorResponse) {
        if (err.status === 400) { 
          window.alert("Enter Valid Dates");
          this.router.navigate(['/admindashboard/addevent']);
        }
        if (err.status === 404) { 
          window.alert("Enter Valid Dates");
          this.router.navigate(['/admindashboard/addevent']);
        }
      }
    }
    
    );
    
  }

}
