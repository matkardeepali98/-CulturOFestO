// import {​​​​​​​​ Component, OnInit }​​​​​​​​ from'@angular/core';
// import {​​​​​​​​ ActivatedRoute, Router }​​​​​​​​ from'@angular/router';
// import {​​​​​​​​ Event }​​​​​​​​ from'../model/event.model';
// import {​​​​​​​​ Food }​​​​​​​​ from'../model/food.model';
// import {​​​​​​​​ Participant }​​​​​​​​ from'../model/Participant';
// import { EventserviceService } from '../Services/eventservice.service';
// import {​​​​​​​​ ParticipantserviceService }​​​​​​​​ from'../Services/participantservice.service';
 
// @Component({​​​​​​​​
// selector:'app-add-participant',
// templateUrl:'./add-participant.component.html',
// styleUrls: ['./add-participant.component.css']
// }​​​​​​​​)
// export class AddParticipantComponent implements OnInit {​​​​​​​​
//  sampleFoods : Food[]=[];
// participant:Participant;
// foods:Food[]=[];
// food:Food;
// event:Event;
// foodName : string;
// flag = false;
// constructor(private participantService:ParticipantserviceService,private router:Router,private route:ActivatedRoute,private service : EventserviceService) {​​​​​​​​ 
// this.event=new Event();
// this.event.eventId=parseInt(this.route.snapshot.paramMap.get("eventId"));
// this.event.name=this.route.snapshot.paramMap.get("name");
// this.event.price=parseInt(this.route.snapshot.paramMap.get("price"));
//   }​​​​​​​​
 
// ngOnInit() {​​​​​​​​
// this.participant=new Participant();
// this.food = new Food();
// // if(!this.event.foods.length)

// // if (!this.event.foods.length) 
// // this.flag = false;
// // else{
// this.foods = this.service.gettempEvent().foods;
// // this.flag = true;
// // }
//   }​​​​​​​​
 
// addParticipants(){​​​​​​​​
// console.log(this.participant);
// console.log(this.foodName);
// for(var i=0;i<this.foods.length;i++){
//   if(this.foodName == this.foods[i].name)
//   this.food = this.foods[i];

// }
// //for(var i = 0; i < this.foods.length;i++)
// console.log(this.food);
// this.sampleFoods.push(this.food);
// this.service.savetempfoodlist(this.sampleFoods);
// this.participant.foods = this.sampleFoods;
// // this.participantService.addParticipant(this.participant).subscribe(x=>(alert("Participants Added successfully")));
// this.participantService.saveparticipantslocally(this.participant);
// this.router.navigate(['/customerdashboard/bookevent',this.event]);
//   }​​​​​​​​

 
// }​​​​​​​​

import {​​​​​​​​ Component, OnInit }​​​​​​​​ from'@angular/core';
import { stringify } from '@angular/core/src/util';
import {​​​​​​​​ ActivatedRoute, Router }​​​​​​​​ from'@angular/router';
import {​​​​​​​​ Event }​​​​​​​​ from'../model/event.model';
import {​​​​​​​​ Food }​​​​​​​​ from'../model/food.model';
import {​​​​​​​​ Participant }​​​​​​​​ from'../model/Participant';
import { EventserviceService } from '../Services/eventservice.service';
import {​​​​​​​​ ParticipantserviceService }​​​​​​​​ from'../Services/participantservice.service';
 
@Component({​​​​​​​​
selector:'app-add-participant',
templateUrl:'./add-participant.component.html',
styleUrls: ['./add-participant.component.css']
}​​​​​​​​)
export class AddParticipantComponent implements OnInit {​​​​​​​​
 sampleFoods : Food[]=[];
participant:Participant;
participantList:Participant[];
foods:Food[];
food:Food;
event:Event;
foodName : string;
foodType:string;
flag = false;
error=false;
childError=false;
adultError=false;
childComboList:Food[]=[];
adultComboList:Food[]=[];
comboCheck=false;
constructor(private participantService:ParticipantserviceService,private router:Router,private route:ActivatedRoute,private service : EventserviceService) {​​​​​​​​ 
this.event=new Event();
this.event.eventId=parseInt(this.route.snapshot.paramMap.get("eventId"));
this.event.name=this.route.snapshot.paramMap.get("name");
this.event.price=parseInt(this.route.snapshot.paramMap.get("price"));

  }​​​​​​​​
 
ngOnInit() {​​​​​​​​
this.participant=new Participant();
this.food = new Food();
// if(!this.event.foods.length)

// if (!this.event.foods.length) 
// this.flag = false;
// else{
this.foods = this.service.gettempEvent().foods;
console.log(this.foods);
// this.flag = true;
// }
    this.error=false;
    this.childError=false;
    this.adultError=false;
    this.comboCheck=false;
  }​​​​​​​​
 
addParticipants(){​​​​​​​​
  
if(this.adultError==false){
  if(this.childError==false){
  if(this.error==false){
console.log(this.participant);
console.log("foodname id ="+this.foodName);
if(this.comboCheck==true && Number(this.participant.participantAge)>=18){
     this.participant.foods=this.adultComboList;
     this.service.savetempfoodlist(this.adultComboList);
}
else
if(this.comboCheck==true && Number(this.participant.participantAge)<18){
  this.participant.foods=this.childComboList;
  this.service.savetempfoodlist(this.childComboList);
}
else{

 

//for(var i = 0; i < this.foods.length;i++)
console.log(this.food);
this.sampleFoods.push(this.food);
this.service.savetempfoodlist(this.sampleFoods);
this.participant.foods = this.sampleFoods;
}
// this.participantService.addParticipant(this.participant).subscribe(x=>(alert("Participants Added successfully")));
this.participantService.saveparticipantslocally(this.participant);
this.router.navigate(['/customerdashboard/bookevent',this.event]);
  }
        else{
          alert("Pls Select the appropriate food to continue");
        }
      }else{
      alert("combo is not present for children");
    }
  }else{
    alert("combo is not present for Adults");
  }

  }​​​​​​​​

  // addfood(sampfood : Food){
  //   this.sampleFoods.push(sampfood);
  // }

  selectFood(foodId:number){
   
    if(foodId>0){
      this.comboCheck=false;
      this.adultError=false;
      this.childError=false;
    for(var i=0;i<this.foods.length;i++){
        if(this.foods[i].foodId==foodId){
          this.foodType=this.foods[i].type;
          this.food=this.foods[i];
          break;
        }
    }
     
    if(  (Number(this.participant.participantAge)>=18 && this.foodType.match("Children")) || (Number(this.participant.participantAge)<18 && this.foodType.match("Adult"))){
     
      this.error=true;
    }else{
      this.error=false;
    }
  }else{
    
    if(foodId==-2){
      this.comboCheck=true;
      this.error=false;
      var acount=0,ccount=0;
      for(var i=0;i<this.foods.length;i++){
           if( (this.foods[i].category=="Snacks" && this.foods[i].type=="Adult") || (this.foods[i].category=="Lunch" && this.foods[i].type=="Adult") ){
                 acount++;
                 this.adultComboList.push(this.foods[i]);
           }else{
           if((this.foods[i].category=="Snacks" && this.foods[i].type=="Children") || (this.foods[i].category=="Lunch" && this.foods[i].type=="Children") ){
               this.childComboList.push(this.foods[i]); 
               ccount++;
           }
          }
      }
      
      if(acount<=1 && Number(this.participant.participantAge)>=18){
             
              this.adultError=true;
              
      }
      else
      if(ccount<=1 && Number(this.participant.participantAge)<18){
       
        this.childError=true;
      } 
      
      
    }
    if(foodId==-1){
      this.comboCheck=false;
      
    }
  }
   
  }
}​​​​​​​​
