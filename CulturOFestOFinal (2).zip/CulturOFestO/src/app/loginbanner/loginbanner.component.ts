import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginbanner',
  templateUrl: './loginbanner.component.html',
  styleUrls: ['./loginbanner.component.css']
})
export class LoginbannerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
