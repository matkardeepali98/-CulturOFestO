import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CusteventlistComponent } from './custeventlist.component';

describe('CusteventlistComponent', () => {
  let component: CusteventlistComponent;
  let fixture: ComponentFixture<CusteventlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CusteventlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CusteventlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
