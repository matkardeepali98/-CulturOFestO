import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Event } from '../model/event.model';
import {  Router } from '@angular/router';
import { EventserviceService } from '../Services/eventservice.service';

@Component({
  selector: 'app-custeventlist',
  templateUrl: './custeventlist.component.html',
  styleUrls: ['./custeventlist.component.css']
})
export class CusteventlistComponent implements OnInit {

  eventName:string;
  eventlist : Event[]=[];
  searcheventlist:Event[]=[];
  
  flag = false;
  constructor(private router:Router,private service : EventserviceService) { }

  ngOnInit() {
    this.service.fetchAllEvents().subscribe((r) => { this.eventlist = r;
    this.flag = true;
  },err => {
     if (err instanceof HttpErrorResponse) {
       if (err.status === 404) { 
         this.flag = false;
         
         window.alert("There are no Events!!!");
       }
     }
   });
  }

  bookevent(event : Event){
    this.service.savetempEvent(event);
   this.router.navigate(['/customerdashboard/bookevent',event]);
  }

  searchContent(){
    console.log("inside serch");
    this.service.fetchEventByName(this.eventName).subscribe((data)=>{
      this.searcheventlist=data;
      
    //   console.log(data);
    //   if(data.length==0){
    //   alert("NO Event Found");
    //   this.service.fetchAllEvents().subscribe(r => { this.eventlist = r;}); //if no event found k baad khali list show krna h toh commnt it 
    // }

    this.service.savetempEventlist(this.searcheventlist);
    this.router.navigate(['/customerdashboard/searchcontent']);
     }); 
  }

  search(){
    if(this.eventName != ""){
    this.eventlist = this.eventlist.filter(res=>{
     return res.name.toLocaleLowerCase().match(this.eventName.toLocaleLowerCase());
    })
  }else if(this.eventName ==""){
    this.ngOnInit();
  }
  }

}
