import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Food } from '../model/food.model';

@Injectable({
  providedIn: 'root'
})
export class FoodserviceService {
  
  
  
  base_food_url="http://localhost:9015/food/";
  add_food="add";
  fetch_food="findall";
  delete_food="Delete/";
  update_food="update";
  constructor(private http:HttpClient, private router : Router) { }


  addFood(food:Food){
    console.log(food);
    return this.http.post(this.base_food_url + this.add_food, food);
  }

  fetchFood(){
    return this.http.get<Food[]>(this.base_food_url + this.fetch_food);
  }
  
  deleteFood(foodId:number){
    
    }

    updateFood(food:Food){
      return this.http.put<Food[]>(this.base_food_url + this.update_food, food);
    }

    deleteFoodById(id : number) {
    return this.http.delete<Food[]>(this.base_food_url + this.delete_food + id).subscribe((r) => {alert("Food Deleted");
     this.router.navigate(['../admindashboard/foodlist']);
    }) ;
    }
}
