import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BookEvent } from '../model/bookevent';
import { Event } from '../model/event.model';
import { EventserviceService } from './eventservice.service';
import { LoginserviceService } from './loginservice.service';
import { ParticipantserviceService } from './participantservice.service';

@Injectable({
  providedIn: 'root'
})
export class BookeventserviceService {
  
  
  bookedEvent : BookEvent;
  finalBookedEvent : BookEvent;
  totalPaymentPrice:number;
  bookedOtp:number;


  constructor(private http : HttpClient, private loginservice : LoginserviceService, private participantservice : ParticipantserviceService,private eventService : EventserviceService) { }
  fetchAllEvents(){
    return this.http.post("http://localhost:8082/bookevent-service/BookEventCtrl/getbookings",this.loginservice.getcustinfo());
   }

   saveonlocal(bookevent : BookEvent) {
     console.log("In Saving Booked Event");
    //  console.log(this.eventService.gettempEvent());
    // this.BookedEvent.event = this.eventService.gettempEvent();
    // this.BookedEvent.customer = this.loginservice.getcustinfo();
    // this.BookedEvent.participants = this.participantservice.fetchparticipant(); 
    // this.BookedEvent.status = "Booked";
    this.bookedEvent = bookevent;
  }

  addbook(){
    console.log("Inside addBookingEvent");
    console.log(this.bookedEvent);
    return this.http.post("http://localhost:8082/bookevent-service/BookEventCtrl/addevent",this.bookedEvent);
  }

  savingfinalbookevent(bookevent : BookEvent){
    this.finalBookedEvent = bookevent;
  }
  fetchfinalbookevent(){
    return this.finalBookedEvent;
  }

  downloadReciept(id: number) {
    this.http.get<any>("http://localhost:8082/bookevent-service/BookEventCtrl/downloadstatement/"+ id).subscribe();
  }

  sendotp(mobileNumber:string){
    console.log("In send to "+mobileNumber);
    return this.http.get<any>("http://localhost:8082/bookevent-service/BookEventCtrl/paymentotp/"+mobileNumber);
  }

  saveOtpLocally(otp:number){
    this.bookedOtp=otp;
    console.log("otpsaved"+this.bookedOtp);
  }
  
  getLocallySaveOtp(){
    return this.bookedOtp;
  }

  getPrice(bookEvent: BookEvent) {
    return this.http.post("http://localhost:8082/bookevent-service/BookEventCtrl/getprice",bookEvent);
  }

  savePaymentLocally(totalPrice:number){
    this.totalPaymentPrice=totalPrice;
  }

  getPaymentInfo(){
    return this.totalPaymentPrice;
  }

  clear(){
    this.finalBookedEvent = null;
    this.bookedEvent = null;
  }


}
