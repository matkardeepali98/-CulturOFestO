import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Participant } from '../model/Participant';

@Injectable({
  providedIn: 'root'
})
export class ParticipantserviceService {
  
  partlist : Participant[]=[];

  constructor(private http:HttpClient) { }


  addParticipant(participant:Participant){
     return this.http.post("http://localhost:9200/participant",participant);
  }

  fetachAllParticipants(){
    return this.http.get<Participant[]>("http://localhost:9200/participant");
  }

  saveparticipantslocally(participant : Participant){
this.partlist.push(participant);
  }

  fetchparticipant(): Participant[] {
    return this.partlist;
  }
  clear() {
    this.partlist = [];
  }
}