import { TestBed } from '@angular/core/testing';

import { BookeventserviceService } from './bookeventservice.service';

describe('BookeventserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BookeventserviceService = TestBed.get(BookeventserviceService);
    expect(service).toBeTruthy();
  });
});
