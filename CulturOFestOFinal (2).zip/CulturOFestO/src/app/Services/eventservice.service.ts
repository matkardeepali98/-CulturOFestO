import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Event } from '../model/event.model';
import { Food } from '../model/food.model';

@Injectable({
  providedIn: 'root'
})
export class EventserviceService {
  
  
  
  
  
  
  tempEvent : Event;
  tempEventList : Event[];
tempfoodList : Food[];
  constructor(private http : HttpClient, private router : Router) { }


  fetchAllEvents(){
    return this.http.get<Event[]>("http://localhost:9015/event/findall");
   }

   addEvent(event:Event){
     return this.http.post("http://localhost:9015/event/add",event);
   }

   getEventById(eventId:number){
     return this.http.get<Event>("http://localhost:9015/event/findall");
   }

   fetchEventByName(eventName:string){
     return this.http.get<Event[]>("http://localhost:9015/event/findbyname/"+eventName);
   }

   savetempEvent(even: Event) {
   this.tempEvent = even;
  }
  // savetempfood(food: Food) {
  //   this.tempEvent.foods.push(food);
  //  return this.http.post("http://localhost:9015/event/update",this.tempEvent);
  // }

  savefoodinevent(food: Food) {
    this.tempEvent.foods.push(food);
    this.http.post("http://localhost:9015/event/update",this.tempEvent).subscribe((r)=>this.router.navigate(['/admindashboard/eventlist']));
  }
  deleteEventById(eventId: number) {
    this.http.delete("http://localhost:9015/event/Delete/"+eventId).subscribe((r)=>this.router.navigate(['/admindashboard']));
  }

  // nullevent() {
  //   this.tempEvent = null;
  // }
  savetempfoodlist(sampleFoods: Food[]) {
    this.tempfoodList = sampleFoods;
  }
  gettempfoodlist(){
    return this.tempfoodList;
  }
  savetempEventlist(eventlist: Event[]) {
    this.tempEventList = eventlist;
  }
  gettempEventlist(){
return this.tempEventList
  }
  gettempEvent() {
    return this.tempEvent;
   }

  clear() {
    this.tempEvent = null;
  }
}
