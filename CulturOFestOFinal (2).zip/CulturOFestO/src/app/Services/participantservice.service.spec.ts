import { TestBed } from '@angular/core/testing';

import { ParticipantserviceService } from './participantservice.service';

describe('ParticipantserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ParticipantserviceService = TestBed.get(ParticipantserviceService);
    expect(service).toBeTruthy();
  });
});
