import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from '../model/customer';
import { Login } from '../model/login';

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {
  
  
  loggedInCust : Customer;

  base_register_url="http://localhost:7174/login";
add_register="/addcust";
fetch_register="/getall";
base_login_url="http://localhost:7174/login/";
   check_login="check";
   gerate_otp="/generateotp/";
   verify="/changepass/{username}/{pass}/{b}";

  constructor(private http:HttpClient) { }
  addLogin(login:Login){
    console.log(login);
    return this.http.post(this. base_register_url+ this.add_register, login);
  // return this.http.post("http://festcustservice.herokuapp.com" + "/login" + this.add_register, login);
  }

  checkLogin(login: Login) {
    console.log(login);
    return this.http.post(this. base_register_url+ "/check", login);
   // return this.http.post("http://festcustservice.herokuapp.com" + "/login"+ "/check", login);
  }

  saveLoggedCustomer(cust : Customer){
    this.loggedInCust = cust;
      }

  getcustinfo() {
    return this.loggedInCust;
  }

  clear() {
    this.loggedInCust = null;
  }

  generateOTP(userName:string,securityans:string){
    // return this.http.get<Login[]>(this.base_login_url + this.generateOTP+ userName+"/"+securityans);
     return this.http.get<any>("http://localhost:7174/login/generateotp/"+userName+"/"+securityans);
   }
 
   verifyOTP(userName:string,password:string,b:boolean,login:Login){
     return this.http.put<Login[]>("http://localhost:7174/login/changepass/"+userName+"/"+password+"/"+b,login);
   }
   
}
