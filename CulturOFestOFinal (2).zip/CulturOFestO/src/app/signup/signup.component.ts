import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../model/customer';
import { Login } from '../model/login';
import { LoginserviceService } from '../Services/loginservice.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  login: Login;
  customer:Customer;
  confirmpassword : string;
  
  // message: any;
  // confirm_password : string ;
  // password: string;
  // userName: string;
  constructor(private service:LoginserviceService, private router:Router) { }

  ngOnInit() {
    this.login = new Login();
    this.customer = new Customer();
  }
  onSubmit(){
 
    this.login.customer = this.customer;
    if(this.login.userName == "ADMIN" )
    window.alert("Username already exists!!! Please change it");
    else
    if(this.login.password == this.confirmpassword)
    this.service.addLogin(this.login).subscribe((r : Login) => {
      this.login = r;
      if(this.login.loginId == null)
      window.alert("Something went wrong, Please try again later");
      else
      window.alert("SignUp done successfully");
      this.router.navigate(['../loginbanner/login']);
      
    },err => {
      if (err instanceof HttpErrorResponse) {
        if (err.status === 404) { 
          
          window.alert("Username already exists!!!");
        }
      }
    });
    else
    window.alert("Check Password Again!!!");
  }
  
}
