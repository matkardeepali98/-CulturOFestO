import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Event } from '../model/event.model';
import { EventserviceService } from '../Services/eventservice.service';

@Component({
  selector: 'app-searchcontent',
  templateUrl: './searchcontent.component.html',
  styleUrls: ['./searchcontent.component.css']
})
export class SearchcontentComponent implements OnInit {

  eventName:string;
  eventlist : Event[]=[];
  searcheventlist:Event[]=[];
  
  flag = false;
  constructor(private router:Router,private service : EventserviceService) { }

  ngOnInit() {
    this.eventlist = this.service.gettempEventlist();
    console.log(this.eventlist);
  
  }

  bookevent(event : Event){
    this.service.savetempEvent(event);
   this.router.navigate(['/customerdashboard/bookevent',event]);
  }

  search(){
    console.log("inside serch");
    this.service.fetchEventByName(this.eventName).subscribe(data=>{
      this.eventlist=data;
      
    //   console.log(data);
    //   if(data.length==0){
    //   alert("NO Event Found");
    //   this.service.fetchAllEvents().subscribe(r => { this.eventlist = r;}); //if no event found k baad khali list show krna h toh commnt it 
    // }

    this.service.savetempEventlist(this.eventlist);
     }); 
  }

}
