import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Event } from '../model/event.model';
import { EventserviceService } from '../Services/eventservice.service';

@Component({
  selector: 'app-eventlist',
  templateUrl: './eventlist.component.html',
  styleUrls: ['./eventlist.component.css']
})
export class EventlistComponent implements OnInit {

  eventlist : Event[];
  flag = false;
  eventName: string;
  constructor(private service : EventserviceService, private router : Router) { }

  ngOnInit() {
    this.service.fetchAllEvents().subscribe((r) => { this.eventlist = r;
    this.flag = true;
  },err => {
     if (err instanceof HttpErrorResponse) {
       if (err.status === 404) { 
         this.flag = false;
         
         window.alert("There are no Events!!!");
       }
     }
   });
  }

  addFood(even : Event){
    this.service.savetempEvent(even);
    this.router.navigate(['/admindashboard/addeventfood']);
  }
  delete(et : Event){
    this.service.deleteEventById(et.eventId);
  }
  search(){
    if(this.eventName != ""){
    this.eventlist = this.eventlist.filter(res=>{
     return res.name.toLocaleLowerCase().match(this.eventName.toLocaleLowerCase());
    })
  }else if(this.eventName ==""){
    this.ngOnInit();
  }
  }
}
