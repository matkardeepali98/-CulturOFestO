import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../model/customer';
import { Login } from '../model/login';
import { LoginserviceService } from '../Services/loginservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login: Login;
  customer:Customer;
  inputType = "password"
  
  // message: any;
  // confirm_password : string ;
  // password: string;
  // userName: string;
  constructor(private service:LoginserviceService, private router : Router) { }

  ngOnInit() {
    this.login = new Login();
    
  }
  onSubmit(){
 
    if(this.login.userName == "ADMIN" && this.login.password == "Shubham1")
    this.router.navigate(['../admindashboard/eventlist']);
else
    this.service.checkLogin(this.login).subscribe((r : Customer) => {
      this.customer= r;
      this.service.saveLoggedCustomer(this.customer);
      this.router.navigate(['../customerdashboard/home']);
      
    },err => {
      if (err instanceof HttpErrorResponse) {
        if (err.status === 404) { 
          
          window.alert("Credentials Are Wrong");
        }
      }
    })
  }
  toggle() {
    if (this.inputType == "password")
      this.inputType = "text"
    else
      this.inputType = "password"
  }
}
