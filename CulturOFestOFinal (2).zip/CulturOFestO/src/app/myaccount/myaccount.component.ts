import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { LoginserviceService } from '../Services/loginservice.service';

@Component({
  selector: 'app-myaccount',
  templateUrl: './myaccount.component.html',
  styleUrls: ['./myaccount.component.css']
})
export class MyaccountComponent implements OnInit {

  cust : Customer;
  constructor(private service : LoginserviceService) { }

  ngOnInit(): void {
    this.cust = this.service.getcustinfo();
    console.log(this.cust);
      
    
  }
}
