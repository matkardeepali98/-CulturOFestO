import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Food } from '../model/food.model';
import { EventserviceService } from '../Services/eventservice.service';
import { FoodserviceService } from '../Services/foodservice.service';
import { LoginserviceService } from '../Services/loginservice.service';

@Component({
  selector: 'app-admindashboard',
  templateUrl: './admindashboard.component.html',
  styleUrls: ['./admindashboard.component.css']
})
export class AdmindashboardComponent implements OnInit {

  event:Event[]=[];
  food:Food[]=[];
  eventName:string;
  tablediv:boolean;
  logo:boolean;
  constructor(private router: Router,private route: ActivatedRoute,private foodservice:FoodserviceService, private eventservice:EventserviceService, private loginservice:LoginserviceService) { }

  ngOnInit() {
    this.logo=false;
    this.findFood();
  }

  logof(){
    this.tablediv=false;
  }
  showevents(){
    this.tablediv=true;
    console.log("events k andr");   
  }

  findFood(){
    this.foodservice.fetchFood().subscribe(response=>{
      this.food = response;
    })
  }

  logout(){
this.eventservice.clear();
this.loginservice.clear();
    this.router.navigate(['../loginbanner/login']);
  }

}
