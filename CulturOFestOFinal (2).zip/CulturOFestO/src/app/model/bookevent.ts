import { Customer } from "./customer";
import { Event } from "./event.model";
import { Participant } from "./Participant";

export class BookEvent{
    bookId:number;
    customer:Customer;
    status:string;
    event:Event;
    participants:Participant[];
}