export class Food{
    foodId:number;
    name:string;
    price:number;
    type:string;
    category:string;
}