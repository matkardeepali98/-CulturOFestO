export class Customer{
    custId:number;
    custName:string;
    age: number;
    mobile:string;
    emailId:string;
   


}