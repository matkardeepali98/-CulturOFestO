import { Customer } from "./customer";

export class Login {
    loginId:number;
    userName:String;
    password:String;
    securityans : string;
    customer:Customer;
    
}
