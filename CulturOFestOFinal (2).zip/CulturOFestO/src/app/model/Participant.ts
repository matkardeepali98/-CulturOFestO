import { Food } from "./food.model";

export class Participant{
    participantId:number;
    participantName:string;
    participantMobileNo:string;
    participantAge:number;
    foods:Food[];
} 