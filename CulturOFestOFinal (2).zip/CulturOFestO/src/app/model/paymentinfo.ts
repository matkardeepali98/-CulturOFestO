export class PaymentInfo{
    paymentDate:string;
    paymentPrice:number;
    eventName:string;
    eventVenue:string;
    eventDate:string;
}