import { Food } from "./food.model";

export class Event{
    eventId:number;
    name:string;
    venue:string;
    price: number;
    dateFrom:Date;
    dateTo:Date;
    lastDate:Date;
    foods : Food[];
    
}