import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Food } from '../model/food.model';
import { EventserviceService } from '../Services/eventservice.service';
import { FoodserviceService } from '../Services/foodservice.service';

@Component({
  selector: 'app-addfood',
  templateUrl: './addfood.component.html',
  styleUrls: ['./addfood.component.css']
})
export class AddfoodComponent implements OnInit {

  @ViewChild("addForm") addform: NgForm;
  foodId:number;
  type:string;
  food:Food;
  submitted:boolean;
  tablediv:boolean;
  eventName: string;
  tempEvent : Event;

  constructor(private router:Router,private route: ActivatedRoute,private foodservice:FoodserviceService,private eventservice:EventserviceService) { }

  ngOnInit() {
    this.foodId =this.route.snapshot.params["foodId"];
    if(this.foodId){
      console.log(this.foodId);
      this.update(this.food);
     
    }
    
  }

  onSubmit() {
    console.log("inside onsubmit");
    
      this.Foodadd(this.addform.value);
    
  }

 
  Foodadd(food: Food){
    console.log("inside add");
    console.log(food.name);
    console.log(food.price);
    console.log(food.type);
    console.log(food.category);
    this.foodservice.addFood(food).subscribe((r : Food) =>{
      this.food = r;
      console.log(this.food.foodId);
      
      // this.eventservice. (this.food).subscribe((r :Event)=> {this.tempEvent = r;
      // this.eventservice.nullevent();
      // });
      this.redirectHome();});  
  }
  
  redirectHome(){
    window.alert("Food added Successfully")
    this.router.navigate(['/admindashboard/foodlist']);
  }

  submitevent(){
    if(this.eventName=='Holi'){
      this.tablediv=true;

      console.log("event name submitted");
    }else{
      console.log("No event present");
    }  
  }

  update(food:Food){
    this.submitted=true;
    this.foodservice.updateFood(food).subscribe(); 
  }
}
