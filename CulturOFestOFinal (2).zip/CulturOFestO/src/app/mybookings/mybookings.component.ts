import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookEvent } from '../model/bookevent';

import { BookeventserviceService } from '../Services/bookeventservice.service';
import { LoginserviceService } from '../Services/loginservice.service';

@Component({
  selector: 'app-mybookings',
  templateUrl: './mybookings.component.html',
  styleUrls: ['./mybookings.component.css']
})
export class MybookingsComponent implements OnInit {

  bookeventlist : BookEvent[];
  eventName : string;
  flag = false;
  totalPrice: number;
  constructor(private service : BookeventserviceService, private router : Router, private bookeventService : BookeventserviceService) { }

  ngOnInit() {
    this.service.fetchAllEvents().subscribe((r : BookEvent[]) => { this.bookeventlist = r;
    this.flag = true;

  },err => {
     if (err instanceof HttpErrorResponse) {
       if (err.status === 404) { 
         this.flag = false;
         
         window.alert("There are no Bookings till yet!!!");
       }
     }
   });

}
search(){
  if(this.eventName != ""){
  this.bookeventlist = this.bookeventlist.filter(res=>{
   return res.event.name.toLocaleLowerCase().match(this.eventName.toLocaleLowerCase());
  })
}else if(this.eventName ==""){
  this.ngOnInit();
}
}

viewQR(event : BookEvent){
  this.bookeventService.savingfinalbookevent(event);
  
  this.bookeventService.getPrice(event).subscribe((r : number) => {
    this.totalPrice = r;
    this.bookeventService.savePaymentLocally(this.totalPrice);
    this.router.navigate(["../customerdashboard/qrcode"]);
  })
}

download(bookevent : BookEvent){
  this.bookeventService.downloadReciept(bookevent.bookId);
  window.alert("Your File Has Been Downloaded");
  this.router.navigate(["../customerdashboard/mybookings"]);

}
downloadPdf(bookEvent:BookEvent){
  this.bookeventService.savingfinalbookevent(bookEvent);
  this.bookeventService.getPrice(bookEvent).subscribe((r : number) => {
    this.totalPrice = r;
    this.bookeventService.savePaymentLocally(this.totalPrice);
    this.router.navigate(["..//customerdashboard/bookingdetailspdf",bookEvent.event]);
  })
  
}

}
